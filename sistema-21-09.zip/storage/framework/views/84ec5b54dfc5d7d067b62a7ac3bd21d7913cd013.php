<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header" data-background-color="purple">
				<h4 class="title">Pedido: <b><?php echo e($pedido->id); ?></b> | Repositor: <b><?php echo e($pedido->repositor); ?></b></h4>
				<p class="category">Abaixo estão os produtos deste pedido</p>
			</div>
			<div class="card-content table-responsive">
				<table class="table">
					<thead class="text-primary">
						<th>Código</th>
						<th>Produto</th>
						<th>Quantidade</th>
						<th>Valor Unitário</th>
						<th>Ações</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($produto->codigo); ?></td>
							<td><?php echo e($produto->nome); ?> - <?php echo e($produto->modelo); ?></td>
							<td><?php echo e($produto->qtde); ?></td>
							<td><?php echo e(formata_dinheiro($produto->preco)); ?></td>
							<td class="td-actions text-right">
								<button type="button" rel="tooltip" title="Editar" class="btn btn-primary btn-simple btn-xs">
									<i class="material-icons">edit</i>
								</button>
								<button type="button" rel="tooltip" title="Deletar" class="btn btn-danger btn-simple btn-xs delete">
									<i class="material-icons">close</i>
								</button>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<h4 class="text-right"><b>Total: <?php echo e(formata_dinheiro($pedido->valor)); ?></b></h4>
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('post-script'); ?>
<script>
	$(".delete").on("submit", function(){
		return confirm("Tem certeza que deseja deletar este item?");
	});
</script>

<?php $__env->stopSection(); ?>									
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>