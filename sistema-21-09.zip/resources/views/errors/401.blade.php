<h2>{{ $exception->getMessage() }}</h2>
<a href="{{route('user_home')}}" >Voltar</a>