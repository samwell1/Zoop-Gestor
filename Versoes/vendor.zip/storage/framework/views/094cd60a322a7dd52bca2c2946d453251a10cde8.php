<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<!-- Button trigger modal -->
		<button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">
			<i class="fa fa-plus"> </i> Usuário
		</button>
	</div>
</div>
<div class="row">
	<div class="col-lg-12 col-md-12">
		<div class="card card-nav-tabs">
			<div class="card-header" data-background-color="purple">
				<div class="nav-tabs-navigation">
					<div class="nav-tabs-wrapper">
						<span class="nav-tabs-title">Tarefas:</span>
						<ul class="nav nav-tabs" data-tabs="tabs">
							<li class="active">
								<a href="#info" data-toggle="tab">
									<i class="material-icons">account_box</i>
									Usuários
								<div class="ripple-container"></div></a>
							</li>
							<li class="">
								<a href="#funcoes" data-toggle="tab">
									<i class="material-icons">assignment_turned_in</i>
									Funções
								<div class="ripple-container"></div></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="card-content">
				<div class="tab-content">
					<div class="tab-pane active" id="info">
						<table class="table">
							<thead class="text-primary">
								<th>Nome</th>
								<th>Email</th>
								<th>Ações</th>
							</thead>
							<tbody>
								<?php if(count($usuarios) === 0 ): ?>
								<tr><td>
									<h3>
										Nenhum produto cadastrado
									</h3>
								</td>
								</tr>
								<?php endif; ?>
								<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($usuario->name); ?></td>
									<td><?php echo e($usuario->email); ?></td>
									<td class="td-actions text-right">
										<button type="button" rel="tooltip" title="Editar" class="btn btn-primary btn-simple btn-xs" data-toggle="modal" data-target="#editar<?php echo e($usuario->id); ?>">
											<i class="material-icons">edit</i>
										</button>
										<form action="<?php echo e(route('deletar_produto')); ?>" method="POST">
											<?php echo e(csrf_field()); ?>

											<input type="hidden" value="<?php echo e($usuario->id); ?>" name="idprod">
											<button type="submit" rel="tooltip" title="Deletar" class="btn btn-danger btn-simple btn-xs delete">
												<i class="material-icons">close</i>
											</button>
										</form>
									</td>
								</tr>
								<!-- editar -->
								<div class="modal fade" id="editar<?php echo e($usuario->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
									<div class="modal-dialog" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												<h4 class="modal-title" id="myModalLabel">Editar produto</h4>
											</div>
											<form enctype="multipart/form-data" action="<?php echo e(route('editar_produto')); ?>"method="POST">
												<?php echo e(csrf_field()); ?>

												<input type="hidden" name="idprod" value="<?php echo e($usuario->id); ?>" class="form-control" >
												<div class="modal-body">
													<div class="row">
														<div class="col-md-4">
															<div class="form-group label-floating">
																<label class="control-label">Nome</label>
																<input type="text" name="nome" value="<?php echo e($usuario->name); ?>" class="form-control" >
															</div>
														</div>
														<div class="col-md-4">
															<div class="form-group label-floating">
																<label class="control-label">Modelo</label>
																<input type="text" name="modelo" value="<?php echo e($usuario->email); ?>" class="form-control" >
															</div>
														</div>
														<div class="col-md-4">
															<div class="form-group label-floating">
																<label class="control-label">Código</label>
																<input type="text" name="codigo" value="<?php echo e($usuario->password); ?>" class="form-control" >
															</div>
														</div>
													</div>
													<div class="clearfix"></div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
													<button type="submit" class="btn btn-primary">Cadastrar</button>
												</div>
											</form>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<div class="tab-pane" id="funcoes">
						<table class="table">
							<thead class="text-primary">
								<th>Nome</th>
								<th>Email</th>
								<th>Administrador</th>
								<th>Repositor</th>
								<th>Ações</th>
							</thead>
							<tbody>
								<?php if(count($usuarios) === 0 ): ?>
								<tr><td>
									<h3>
										Nenhum usuario cadastrado
									</h3>
								</td>
								</tr>
								<?php endif; ?>
								<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<form action="<?php echo e(route('mudar_funcao')); ?>" method="post">
									<tr>
										<td><?php echo e($usuario->name); ?></td>
										<td><?php echo e($usuario->email); ?></td>
										<input type="hidden" name="email"
									value="<?php echo e($usuario->email); ?>"></td>
									<td><input type="checkbox" <?php echo e($usuario->hasRole('admin') ?
									'checked' : ''); ?> name="role_admin"></td>
									<td><input type="checkbox" <?php echo e($usuario->hasRole('repositor') ?
									'checked' : ''); ?> name="role_repositor"></td>
									<?php echo e(csrf_field()); ?>

									<td><button type="submit"
									class="btn btn-warning btn-fill">Mudar permissão</button></td>
									
								</tr>
							</form>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Cadastrar usuário</h4>
			</div>
			<form enctype="multipart/form-data" action="<?php echo e(route('cadastrar-produto')); ?>" id="upload" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="modal-body">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">Nome</label>
								<input type="text" name="nome" class="form-control" >
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">Email</label>
								<input type="email" name="email" class="form-control" >
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">Código</label>
								<input type="text" name="codigo" class="form-control" >
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-3">
							<div class="form-group label-floating">
								<label class="control-label">Quantidade</label>
								<input type="number" name="quantidade" class="form-control" >
							</div>
						</div>
						<div class="col-md-5">
							<div class="form-group is-empty is-fileinput">
								
								<input type="file" name="imagem" id="image">
								<div class="input-group">
									<input type="text" readonly="" class="form-control" placeholder="Selecione uma imagem">
									<span class="input-group-btn input-group-sm">
										<button type="button" class="btn btn-fab btn-fab-mini">
											<i class="fa fa-file-image-o"></i>
										</button>
										</span>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label class="control-label"></label>
										<img src="" id="preview" style="height:100px;width:auto;">
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
							<button type="submit" class="btn btn-primary">Cadastrar</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>
		
		<?php $__env->startSection('post-script'); ?>
	<script>
		$(".delete").on("submit", function(){
			return confirm("Tem certeza que deseja deletar este item?");
		});
	</script>
	<script>
		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				
				reader.onload = function (e) {
					$('#preview').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			}
		}
		$("#image").change(function(){
			readURL(this);
		});
	</script>
	<?php $__env->stopSection(); ?>						
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>