<?php $__env->startSection('content'); ?>
<div class="row">
	                    <div class="col-md-8">
	                        <div class="card">
	                            <div class="card-header" data-background-color="purple">
	                                <h4 class="title">Seu Perfil</h4>
									<p class="category">Edite seu perfil</p>
	                            </div>
	                            <div class="card-content">
	                                <form action="<?php echo e(url('admin_editar_perfil')); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($usuario->id); ?>" name="idUser">
	                                    <div class="row">
	                                        <div class="col-md-6">
												<div class="form-group label-floating">
													<label class="control-label">Nome</label>
													<input type="text" value="<?php echo e($usuario->name); ?>" name="nome" class="form-control" >
												</div>
	                                        </div>
	                                        <div class="col-md-6">
												<div class="form-group label-floating">
													<label class="control-label">Email</label>
													<input type="email" value="<?php echo e($usuario->email); ?>" name="email" class="form-control" >
												</div>
	                                        </div>
	                                    </div>
	                                    <div class="row">
	                                        <div class="col-md-6">
												<div class="form-group label-floating">
													<label class="control-label">Senha Atual</label>
													<input type="password" name="confirmpassword" class="form-control" >
												</div>
	                                        </div>
	                                        <div class="col-md-6">
												<div class="form-group label-floating">
													<label class="control-label">Senha Nova</label>
													<input type="password" name="password" class="form-control" >
												</div>
	                                        </div>
	                                    </div>
	                                    <button type="submit" class="btn btn-primary pull-right">Salvar</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
						<div class="col-md-4">
    						<div class="card card-profile">
    							<div class="card-avatar">
    								<a href="#pablo">
    									<img class="img" src="https://winklevosscapital.com/wp-content/uploads/2014/10/2014-09-16-Anoynmous-The-Rise-of-Personal-Networks.jpg" />
    								</a>
    							</div>

    							<div class="content">
    								<h6 class="category text-gray"><?php echo e($usuario->roles->first()->name); ?></h6>
    								<h4 class="card-title"><?php echo e($usuario->name); ?></h4>
    								<p class="card-content">
										Cadastrado em: <?php echo e(formata_data($usuario->created_at)); ?>

    								</p>
    								<a href="#pablo" class="btn btn-primary btn-round">Mudar Foto</a>
    							</div>
    						</div>
		    			</div>
	                </div>
		<?php $__env->stopSection(); ?>
		
		<?php $__env->startSection('post-script'); ?>
<script>
		$(".delete").on("submit", function(){
			return confirm("Tem certeza que deseja deletar este item?");
		});
	</script>
	<script>
		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				
				reader.onload = function (e) {
					$('#preview').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			}
		}
		$("#image").change(function(){
			readURL(this);
		});
	</script>
	<?php $__env->stopSection(); ?>						
<?php echo $__env->make('layouts.repositor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>