<h2><?php echo e($exception->getMessage()); ?></h2>
<a href="<?php echo e(route('user_home')); ?>" >Voltar</a>