<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-12">
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header" data-background-color="purple">
				<h4 class="title">Pedido: <b><?php echo e($pedido->id); ?></b> | Repositor: <b><?php echo e($pedido->repositor); ?></b></h4>
				<p class="category">Abaixo estão os produtos deste pedido</p>
			</div>
			<div class="card-content table-responsive">
				<table class="table">
					<thead class="text-primary">
						<th>Código</th>
						<th>Produto</th>
						<th>Quantidade</th>
						<th>Valor Unitário</th>
						<th>Valor Total</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($produto->codigo); ?></td>
							<td><?php echo e($produto->nome); ?> - <?php echo e($produto->modelo); ?></td>
							<td><?php echo e($produto->qtde); ?></td>
							<td><?php echo e(formata_dinheiro($produto->preco)); ?></td>
							<td><?php echo formata_dinheiro($produto->preco * $produto->qtde)?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<h4 class="text-right"><b>Total: <?php echo e(formata_dinheiro($pedido->valor)); ?></b></h4>
			</div>
		</div>
	</div>
</div>
<?php if($pedido->boleto == null || $pedido->boleto == ''): ?>
<form action="<?php echo e(URL::to('user/pedido/' . $pedido->id.'/emitBoleto')); ?>" method="POST">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" value="<?php echo e($pedido->id); ?>" name="idPedido">
	<input type="hidden" value="<?php echo e($pedido->id_pdv); ?>" name="idPdv">
<button type="submit" class="btn btn-success pull-right">
	<i class="fa fa-plus"> </i> Emitir Boleto
</button>
</form>
<?php endif; ?>

<?php if($pedido->nf != null || $pedido->nf != ''): ?>
<form action="<?php echo e(URL::to('user/pedido/' . $pedido->id.'/enviNfe')); ?>" method="POST">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" value="<?php echo e($pedido->id); ?>" name="idPedido">
	<input type="hidden" value="<?php echo e($pedido->id_pdv); ?>" name="idPdv">
	<button type="submit" class="btn btn-info pull-right">
		<i class="fa fa-plus"> </i> enviar Nota fiscal
	</button>
</form>

<?php else: ?>
<form action="<?php echo e(URL::to('user/pedido/' . $pedido->id.'/emitNfe')); ?>" method="POST">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" value="<?php echo e($pedido->id); ?>" name="idPedido">
	<input type="hidden" value="<?php echo e($pedido->id_pdv); ?>" name="idPdv">
	<button type="submit" class="btn btn-info pull-right">
		<i class="fa fa-plus"> </i> Emitir Nota fiscal
	</button>
</form>
<?php endif; ?>

<?php if($pedido->boleto != null || $pedido->boleto != ''): ?>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header" data-background-color="purple">
				<h4 class="title">Status: <b><?php echo e($boleto->status); ?></b> | Data de Vencimento Boleto: <b> <?php echo e(formata_data($boleto->due_date)); ?></b> </h4>
				<p class="category">Abaixo estão as ações do boleto</p>
			</div>
			<div class="card-content table-responsive">
				<table class="table">
					<thead class="text-primary">
						<th>Data</th>
						<th>Descrição</th>
						<th>Notas</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $boleto->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($logs->created_at); ?></td>
							<td><?php echo e($logs->description); ?></td>
							<td><?php echo e($logs->notes); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('post-script'); ?>
<script>
	$(".delete").on("submit", function(){
	return confirm("Tem certeza que deseja deletar este item?");
	});
	</script>
	
	<?php $__env->stopSection(); ?>										
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>