<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12">
		<div class="card card-nav-tabs">
			<div class="card-header" data-background-color="purple">
				<div class="nav-tabs-navigation">
					<div class="nav-tabs-wrapper">
						<span class="nav-tabs-title">Estoques:</span>
						<ul class="nav nav-tabs" data-tabs="tabs">
							<li class="active">
								<a href="#produto" data-toggle="tab">
									<i class="material-icons">local_offer</i>
									Produtos
								<div class="ripple-container"></div></a>
							</li>
							<li class="">
								<a href="#pdv" data-toggle="tab">
									<i class="material-icons">store</i>
									Pontos de Venda
								<div class="ripple-container"></div></a>
							</li>
							<li class="">
								<a href="#repositor" data-toggle="tab">
									<i class="material-icons">transfer_within_a_station</i>
									Repositor
								<div class="ripple-container"></div></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			
			<!-- Table PRODUTOS -->
			<div class="card-content">
				<div class="tab-content">
					<div class="tab-pane active" id="produto">
						<table class="table">
					<thead class="text-primary">
						<th>Código</th>
						<th>Produto/Modelo</th>
						<th>Estoque</th>
						<th>Ações</th>
					</thead>
					<tbody>
					<?php if(count($produtos) === 0 ): ?>
						<tr><td>
							<h3>
								Nenhum produto cadastrado
							</h3>
							</td>
						</tr>
						<?php endif; ?>
						<?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($produto->codigo); ?></td>
							<td><?php echo e($produto->nome); ?>/<?php echo e($produto->modelo); ?></td>
							<td><?php echo e($produto->quantidade); ?></td>
							<td class="td-actions text-right">
								<button type="button" rel="tooltip" title="Editar" class="btn btn-primary btn-simple btn-xs" data-toggle="modal" data-target="#editar<?php echo e($produto->id); ?>">
									<i class="material-icons">edit</i>
								</button>
								<form action="<?php echo e(route('deletar_produto')); ?>" class="delete" method="POST">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($produto->id); ?>" name="idprod">
									<button type="submit" rel="tooltip" title="Deletar" class="btn btn-danger btn-simple btn-xs delete">
										<i class="material-icons">close</i>
									</button>
								</form>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
					</div>
					
					<!-- Table PONTOS VENDA -->
					<div class="tab-pane" id="pdv">
						<table class="table">
					<thead class="text-primary">
						<th>Ponto de Venda</th>
						<th>Produto/Modelo</th>
						<th>Quantidade</th>
						<th>Ações</th>
					</thead>
					<tbody>
					<?php if(count($pontosvenda) === 0 ): ?>
						<tr><td>
							<h3>
								Nenhum ponto de venda cadastrado
							</h3>
							</td>
						</tr>
						<?php endif; ?>
						<?php $__currentLoopData = $pontosvenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pontovenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($pontovenda->nome); ?></td>
							<?php if($pontovenda->produto == null): ?>
								<td>Sem estoque</td>
							<?php else: ?>
								<td><?php echo e($pontovenda->produto); ?>/<?php echo e($pontovenda->produtomodelo); ?></td>
							<?php endif; ?>
							
							<?php if($pontovenda->estoque == null): ?>
								<td>0</td>
							<?php else: ?>
							<td><?php echo e($pontovenda->estoque); ?></td>
							<?php endif; ?>
							
							
							<td class="td-actions text-right">
								<button type="button" rel="tooltip" title="Editar" class="btn btn-primary btn-simple btn-xs" data-toggle="modal" data-target="#editar<?php echo e($produto->id); ?>">
									<i class="material-icons">edit</i>
								</button>
								<form action="<?php echo e(route('deletar_produto')); ?>" class="delete" method="POST">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($produto->id); ?>" name="idprod">
									<button type="submit" rel="tooltip" title="Deletar" class="btn btn-danger btn-simple btn-xs delete">
										<i class="material-icons">close</i>
									</button>
								</form>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				</div>
		
		<!-- Table REPOSITOR -->
				
				<div class="tab-pane" id="repositor">
						<table class="table">
					<thead class="text-primary">
						<th>Repositor</th>
						<th>Produto/Modelo</th>
						<th>Estoque</th>
						<th>Ações</th>
					</thead>
					<tbody>
					<?php if(count($repositores) === 0 ): ?>
						<tr><td>
							<h3>
								Nenhum repositor cadastrado
							</h3>
							</td>
						</tr>
						<?php endif; ?>
						<?php $__currentLoopData = $repositores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repositor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($repositor->name); ?></td>
							<?php if($repositor->produto == null): ?>
								<td>Sem estoque</td>
							<?php else: ?>
								<td><?php echo e($repositor->produto); ?>/<?php echo e($repositor->produtomodelo); ?></td>
							<?php endif; ?>
							
							<?php if($repositor->estoque == null): ?>
								<td>0</td>
							<?php else: ?>
								<td><?php echo e($repositor->estoque); ?></td>
							<?php endif; ?>
							
							<td class="td-actions text-right">
								<button type="button" rel="tooltip" title="Editar" class="btn btn-primary btn-simple btn-xs" data-toggle="modal" data-target="#editar<?php echo e($produto->id); ?>">
									<i class="material-icons">edit</i>
								</button>
								<form action="<?php echo e(route('deletar_produto')); ?>" class="delete" method="POST">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($produto->id); ?>" name="idprod">
									<button type="submit" rel="tooltip" title="Deletar" class="btn btn-danger btn-simple btn-xs delete">
										<i class="material-icons">close</i>
									</button>
								</form>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>