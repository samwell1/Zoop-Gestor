<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<!-- Button trigger modal -->
		<button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">
			<i class="fa fa-plus"> </i> Ponto de Venda
		</button>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header" data-background-color="purple">
				<h4 class="title">Pontos de Venda</h4>
				<p class="category">Abaixo estão os pontos de venda</p>
			</div>
			<div class="card-content table-responsive">
				<table class="table">
					<thead class="text-primary">
						<th>Nome</th>
						<th>Endereço</th>
						<th>Região/Bairro</th>
						<th>Cidade</th>
						<th>Cadastrado por</th>
						<th>Status</th>
						<th>Ações</th>
					</thead>
					<tbody>
						<?php if(count($pontosvenda) === 0 ): ?>
						<tr><td>
							<h3>
								Nenhum ponto de venda cadastrado
							</h3>
						</td>
						</tr>
						<?php endif; ?>
						<?php $__currentLoopData = $pontosvenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pontovenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($pontovenda->nome); ?></td>
							<td><?php echo e($pontovenda->endereco); ?>, <?php echo e($pontovenda->numero); ?></td>
							<td><?php echo e($pontovenda->regiao); ?></td>
							<td><?php echo e($pontovenda->cidade); ?>/<?php echo e($pontovenda->estado); ?></td>
							<td><?php echo e($pontovenda->repositor); ?></td>
							<?php if($pontovenda->status == 'Ativo'): ?>
							<td><button type="button" rel="tooltip" title="Ponto de venda ativado" class="btn btn-success btn-simple btn-xs"> 
									<i class="fa fa-circle"></i> <?php echo e($pontovenda->status); ?>

								</button> </td>
								<?php elseif($pontovenda->status == 'Pendente'): ?>
							<td>
								<button type="button" rel="tooltip" title="Ponto de venda pendente (contrato, documentos)" class="btn btn-warning btn-simple btn-xs" data-toggle="modal" data-target="#modal<?php echo e($pontovenda->id); ?>"> 
									<i class="fa fa-circle"></i> <?php echo e($pontovenda->status); ?>

								</button></td>
								<?php elseif($pontovenda->status == 'Desativado'): ?>
								<td>
								<button type="button" rel="tooltip" title="Ponto de venda desativado" class="btn btn-danger btn-simple btn-xs" data-toggle="modal" data-target="#editar<?php echo e($pontovenda->id); ?>">
									<i class="fa fa-circle"></i> <?php echo e($pontovenda->status); ?>

								</button></td>
								<?php endif; ?>
								
							<td class="td-actions text-right">
								<button type="button" rel="tooltip" title="Ver" class="btn btn-info btn-simple btn-xs" data-toggle="modal" data-target="#modal<?php echo e($pontovenda->id); ?>"> 
									<i class="fa fa-eye"></i>
								</button>
								<button type="button" rel="tooltip" title="Editar" class="btn btn-primary btn-simple btn-xs" data-toggle="modal" data-target="#editar<?php echo e($pontovenda->id); ?>">
									<i class="material-icons">edit</i>
								</button>
								<form action="<?php echo e(route('deletar_pdv')); ?>" class="delete" method="POST">
									<?php echo e(csrf_field()); ?>

									<input type="hidden" value="<?php echo e($pontovenda->id); ?>" name="idPdv">
									<button type="submit" rel="tooltip" title="Deletar" class="btn btn-danger btn-simple btn-xs delete">
										<i class="material-icons">close</i>
									</button>
								</form>
								</td>
							</tr>
							<!-- Editar -->
							<div class="modal fade" id="editar<?php echo e($pontovenda->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Cadastrar</h4>
									</div>
									<form action="<?php echo e(route('editar_pdv')); ?>" id="upload" method="POST">
										<?php echo e(csrf_field()); ?>

										<input type="hidden" name="idPdv" value="<?php echo e($pontovenda->id); ?>"">
										<div class="modal-body">
											<div class="row">
												<div class="col-md-4">
													<div class="form-group label-floating">
														<label class="control-label">Nome</label>
														<input type="text" name="nome" value="<?php echo e($pontovenda->nome); ?>" class="form-control" >
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group label-floating">
														<label class="control-label">Endereço</label>
														<input type="text" name="endereco" class="form-control"  value="<?php echo e($pontovenda->endereco); ?>">
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group label-floating">
														<label class="control-label">Bairro/Região</label>
														<input type="text" name="regiao" class="form-control" value="<?php echo e($pontovenda->regiao); ?>">
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6">
													<div class="form-group label-floating">
														<label class="control-label">UF</label>
														<select id="uf" default="<?php echo e($pontovenda->estado); ?>" name="estado" class="uf form-control"></select>
													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group label-floating">
														<label class="control-label">Cidade</label>
														<select id="cidade" default="<?php echo e($pontovenda->cidade); ?>"  name="cidade" class="cidade form-control"></select>
													</div>
												</div>
											</div>
											<div class="clearfix"></div>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
											<button type="submit" class="btn btn-primary">Cadastrar</button>
										</div>
									</form>
								</div>
							</div>
						</div> 
						<!-- Estoque -->
						<div class="modal fade" id="modal<?php echo e($pontovenda->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Abastecer estoque</h4>
									</div>
									<form action="" method="POST">
										<?php echo e(csrf_field()); ?>

										<input type="hidden" name="pdv" value="<?php echo e($pontovenda->id); ?>">
										<div class="modal-body">
											<div class="row">
												<div class="col-md-6">
													<div class="form-group label-floating">
														<label class="control-label">Produto</label>
														<select name="produto" class="form-control">
															<?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($produto->id); ?>"><?php echo e($produto->nome); ?> - <?php echo e($produto->modelo); ?> | <b>Estoque: <?php echo e($produto->quantidade); ?></b></option>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</select>
													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group label-floating">
														<label class="control-label">Quantidade</label>
														<input type="number" name="quantidade" class="form-control" >
													</div>
												</div>
											</div>
											<div class="clearfix"></div>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
											<button type="submit" class="btn btn-primary">Cadastrar</button>
										</div>
									</form>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Cadastrar</h4>
			</div>
			<form action="<?php echo e(route('cadastrar-pdv')); ?>" id="upload" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="modal-body">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">Nome</label>
								<input type="text" name="nome" class="form-control" >
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">CNPJ</label>
								<input type="text" name="cnpj" class="form-control" >
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">CEP</label>
								<input type="text" name="endereco" class="form-control" >
							</div>
						</div>
						
					</div>
					<div class="row">
					<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">Endereço</label>
								<input type="text" name="endereco" class="form-control" >
							</div>
						</div>
						<div class="col-md-2">
							<div class="form-group label-floating">
								<label class="control-label">Nº</label>
								<input type="text" name="numero" class="form-control" >
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group label-floating">
								<label class="control-label">Bairro/Região</label>
								<input type="text" name="regiao" class="form-control" >
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group label-floating">
								<label class="control-label">Telefone</label>
								<input type="text" name="telefone" class="form-control" >
							</div>
						</div>
						
					</div>
					
					<div class="row">
					<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">UF</label>
								<select id="uf" name="estado" class="uf form-control"></select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">Cidade</label>
								<select id="cidade" name="cidade" class="cidade form-control"></select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group label-floating">
								<label class="control-label">Email</label>
								<input type="text" name="email" class="form-control" >
							</div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
					<button type="submit" class="btn btn-primary">Cadastrar</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('post-script'); ?>

<script src="/vendor/artesaos/cidades/js/scripts.js"></script>

<script>
	$('.uf').ufs({
		onChange: function(uf){
			$('.cidade').cidades({uf: uf});
		}
	});
</script>

<script>
    $(".delete").on("submit", function(){
        return confirm("Tem certeza que deseja deletar este item?");
    });
</script>


<?php $__env->stopSection(); ?>	

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>